const chatWindow = document.getElementById("chatWindow");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const businessNameInput = document.getElementById("businessName");
const systemPromptInput = document.getElementById("systemPrompt");

let history = [];

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.textContent = text;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

async function sendMessage() {
  const text = userInput.value.trim();
  if (!text) return;

  addMessage("user", text);
  userInput.value = "";

  const payload = {
    message: text,
    businessName: businessNameInput.value,
    systemPrompt: systemPromptInput.value,
    history
  };

  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  addMessage("ai", data.reply);

  history.push({ role: "user", content: text });
  history.push({ role: "assistant", content: data.reply });
}

sendBtn.addEventListener("click", sendMessage);
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendMessage();
});

// add welcome
addMessage("ai", "Hi! This is Tony's AI Assistant for cleaning. What do you need cleaned and where?");
